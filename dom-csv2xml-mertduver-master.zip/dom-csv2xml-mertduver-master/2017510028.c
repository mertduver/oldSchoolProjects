#include <stdio.h>
#include <string.h>

//the program works any order of parameters
//that means you can write -opsys first or -separator first it just doesn't matter.


int main(int argc, char *argv[]) {

    char separator;
    char *opSys;
    //if parameters are correct? else>> print -h parameter
    if (argc == 7 && ((strcmp(argv[3], "-separator") == 0 && strcmp(argv[5], "-opsys") == 0) ||
                      (strcmp(argv[5], "-separator") == 0 && strcmp(argv[3], "-opsys") == 0))) {
        if (strcmp(argv[3], "-separator") == 0) {//set the separator
            if (strcmp(argv[4], "1") == 0)
                separator = ',';
            else if (strcmp(argv[4], "2") == 0)
                separator = '\t';
            else if (strcmp(argv[4], "3") == 0)
                separator = ';';
            else {
                printf("Wrong arguments. Please use [-h] parameter for help\n");
                return (-1);
            }

            if (strcmp(argv[6], "1") == 0)//set the opSys
                opSys = "\r\n";
            else if (strcmp(argv[6], "2") == 0)
                opSys = "\n";
            else if (strcmp(argv[6], "3") == 0)
                opSys = "\r";
            else {
                printf("Wrong arguments. Please use [-h] parameter for help\n");
                return (-1);
            }


        } else if (strcmp(argv[5], "-separator") == 0) {
            if (strcmp(argv[6], "1") == 0)
                separator = ',';
            else if (strcmp(argv[6], "2") == 0)
                separator = '\t';
            else if (strcmp(argv[6], "3") == 0)
                separator = ';';
            else {
                printf("Wrong arguments. Please use [-h] parameter for help\n");
                return (-1);
            }

            if (strcmp(argv[4], "1") == 0)//set the opSys
                opSys = "\r\n";
            else if (strcmp(argv[4], "2") == 0)
                opSys = "\n";
            else if (strcmp(argv[4], "3") == 0)
                opSys = "\r";
            else {
                printf("Wrong arguments. Please use [-h] parameter for help\n");
                return (-1);
            }
        }


        //starting the file reading and writing
        FILE *readingFile;
        FILE *writingFile;


        writingFile = fopen(("./%s", argv[2]), "w+");

        //correction of output file name for lowercase and underscore
        char *outName;
        outName = argv[2];
        outName[strlen(outName) - 4] = '\0';
        for (int i = 0; i < strlen(outName); ++i) {
            if (outName[i] >= 'A' && outName[i] <= 'Z') {
                outName[i] = outName[i] + 32;
            } else if (outName[i] == ' ') {
                outName[i] = '_';
            }
        }
        //writing the root (output file name)
        fputc('<', writingFile);
        fputs(("%s", outName), writingFile);
        fputc('>', writingFile);
        fputs(("%s", opSys), writingFile);

        //this first reading is just for counting the number of columns
        int numberOfColumns = 1;
        readingFile = fopen(("./%s", argv[1]), "r");
        if (readingFile == NULL) {
            perror("Error in opening file");
            return (-1);
        }
        char before;
        char current;
        do {
            current = fgetc(readingFile);
            if (feof(readingFile)) {
                break;
            }
            if (current == separator) {
                numberOfColumns++;
            }//we just need to read first line to count number of columns so break after first line endings
            if (strcmp(opSys, "\r\n") == 0
                && before == '\r'
                && current == '\n') {
                break;
            } else if (strcmp(opSys, "\n") == 0 &&
                       current == '\n') {
                break;
            } else if (strcmp(opSys, "\r") == 0 &&
                       current == '\r') {
                break;
            }
            before = current;
        } while (1);
        //close the reading file and open it again
        fclose(readingFile);
        readingFile = fopen(("./%s", argv[1]), "r");

        char columnNames[numberOfColumns][100];//creates columns array(string array)


        //getting column names
        char buff[255];
        fgets(buff, 255, (FILE *) readingFile);
        char *token;
        int indexNumber = 0;
        char sep[2];
        sep[0] = separator;
        sep[1] = '\0';

        token = strtok(buff, sep);
        strcpy(columnNames[indexNumber], token);
        while (token != NULL) {
            strcpy(columnNames[indexNumber], token);
            indexNumber++;

            token = strtok(NULL, sep);
        }

        //fixing for last column name linefeed problem
        int sizeOfLastElement = strlen(columnNames[numberOfColumns - 1]) - 1;
        if (columnNames[numberOfColumns - 1][sizeOfLastElement - 1] == '\r'
            || columnNames[numberOfColumns - 1][sizeOfLastElement - 1] == '\n') {
            columnNames[numberOfColumns - 1][sizeOfLastElement - 1] = '\0';
        }

        //fixing lowercase and underscore
        for (int j = 0; j < numberOfColumns; ++j) {
            char *str = columnNames[j];
            for (int i = 0; i < strlen(str); ++i) {
                if (str[i] >= 'A' && str[i] <= 'Z') {
                    str[i] = str[i] + 32;
                } else if (str[i] == ' ') {
                    str[i] = '_';
                }
            }
        }

        //reading and creating and writing to xml file
        int rowId = 1;
        fprintf(writingFile, "\t<row_id=\"%d\">%s", rowId, opSys);//first row
        current = fgetc(readingFile);
        do {
            if (feof(readingFile)) {
                break;
            }

            //this for writes one row each time and its inside
            for (int i = 0; i < numberOfColumns; ++i) {
                fprintf(writingFile, "\t\t<%s>", columnNames[i]);
                //this while writes the real data char by char
                while (current != separator && current != '\n' && current != '\r') {
                    fprintf(writingFile, "%c", current);
                    current = fgetc(readingFile);
                }
                fprintf(writingFile, "</%s>%s", columnNames[i], opSys);
                current = fgetc(readingFile);
            }


            //if line has ended then row++
            if (current == '\r' || current == '\n') {
                fprintf(writingFile, "\t</row>%s", opSys);
                rowId++;
                current = fgetc(readingFile);
                if (feof(readingFile)) {
                    break;
                }
                fprintf(writingFile, "\t<row_id=\"%d\">%s", rowId, opSys);
            } else {
                current = fgetc(readingFile);
                if (feof(readingFile)) {
                    break;
                }
            }

        } while (1);

        //closing root, end of file
        fprintf(writingFile, "</%s>", outName);

        //closing the files
        fclose(readingFile);
        fclose(writingFile);

        //this else means parameters are wrong
    } else {
        char flag = 'a';//used as a boolean.
        for (int i = 1; i < argc; ++i) {
            if (strcmp(argv[i], "-h") == 0) {
                flag = 'b';
            }
        }
        if (flag == 'b') {
            printf("Usage of CSV2XML program must be as follows:\n"
                   "CSV2XML <inputfile> <outputfile> [-separator <P1>][-opsys <P2>]\n"
                   "P1 should be 1=comma, 2=tab or 3=semicolon, and P2 should be 1=windows,"
                   "2=linux or 3=macos");
        } else {
            printf("Wrong arguments. Please use [-h] parameter for help\n");
        }
    }
    printf("Job Done Successfully!");
}
