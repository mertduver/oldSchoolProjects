# dom-csv2xml-mertduver
dom-csv2xml-mertduver created by GitHub Classroom 

2017510028

Mert Düver


eksiklikler: içerik boş olduğunda "\<address/\>" yazmak yerine "\<address>\</address>" şeklinde açıp kapıyor.

artıları: parametrelerin sırası önemli değil. Önce opsys parametesini de kullanabilirsiniz. Herhangi hatalı, eksik veya fazla bir parametre girilmesi sonucunda -h kullanmayı öneriyor

not: bu belgeyi düzgün görüntüleyemiyorsanız lütfen raw haline bakınız.
