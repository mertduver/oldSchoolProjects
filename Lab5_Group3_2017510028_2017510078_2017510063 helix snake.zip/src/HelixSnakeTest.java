import java.io.IOException;

public class HelixSnakeTest {

    public static void main(String[] args) throws InterruptedException, IOException {
        MenuDesign m = new MenuDesign();
        m.Menu();
    }
}
