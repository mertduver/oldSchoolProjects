import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import enigma.console.TextAttributes;
import enigma.core.Enigma;

public class DoubleLinkedList {
    private DoubleLinkedListNode head;
    private DoubleLinkedListNode tail;

    public DoubleLinkedList() {

        head = null;
        tail = null;
    }

    public void InsertPosition(String Name, int dataToAdd) {
        DoubleLinkedListNode newNode = new DoubleLinkedListNode(Name, dataToAdd);
        if (head == null & tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            DoubleLinkedListNode temp = head;
            if (dataToAdd > (int) head.getData()) {
                newNode.setNext(head);
                newNode.setPrev(null);
                head = newNode;
            } else {
                while (temp.getNext() != null && dataToAdd < (Integer) temp.getNext().getData()) {
                    temp = temp.getNext();
                }
                newNode.setPrev(temp);
                newNode.setNext(temp.getNext());

                if (temp.getNext() != null) {
                    temp.getNext().setPrev(newNode);
                    temp.setNext(newNode);
                } else {
                    tail = newNode;
                    temp.setNext(newNode);
                }
            }


        }

    }

    public void DeleteLastOne() {
        if (head == null)
            System.out.println("Empty");

        if (head.getNext() == null)
            System.out.println("Empty");

        // Find the second last node
        DoubleLinkedListNode second_last = head;
        while (second_last.getNext().getNext() != null)
            second_last = second_last.getNext();

        // Change next of second last
        second_last.setNext(null);
    }

    public void DisplayOnScreeen() {  //Ekrana Yazd�r�lan B�l�m(Dosyadki veriler yazd�r�l�r
        //Node current will point to head
        DoubleLinkedListNode current = head;

        String[] PrintName = new String[size()];
        int[] PrintScore = new int[size()];
        int i = 0;
        while (current != null) {
            //Prints each node by incrementing the pointer.
            PrintName[i] = current.getName();
            PrintScore[i] = (int) current.getData();
            i++;
            current = current.getNext();
        }

        int k = 10;
        int l = 30;
        if (PrintName.length == 0) {
            System.out.println("Score table is empty.");
        } else {
            Enigma.getConsole().setTextAttributes(new TextAttributes(Color.LIGHT_GRAY));
            Enigma.getConsole().getTextWindow().setCursorPosition(10, 3);
            System.out.println("   Player Name");
            Enigma.getConsole().getTextWindow().setCursorPosition(30, 3);
            System.out.println("Score");
            for (int j = 5; j <= PrintName.length + 4; j++) {
                Enigma.getConsole().getTextWindow().setCursorPosition(k, j);
                System.out.println(j - 4 + "| " + PrintName[j - 5]);
                Enigma.getConsole().getTextWindow().setCursorPosition(l, j);
                System.out.println("=>>" + PrintScore[j - 5]);

            }
        }
    }


    public void AssignWriterMethod() throws IOException {
        //Node current will point to head
        ReadFile();
        DoubleLinkedListNode current = head;

        String[] s = new String[11];
        int i = 0;
        if (head == null) {
            System.out.println("List is empty");
        }
        while (current != null) {
            //Prints each node by incrementing the pointer.
            if (i < 10) {
                s[i] = (String) current.getName() + ";" + Integer.toString((int) current.getData());
                current = current.getNext();
                i++;
            } else {
                current = current.getNext();
            }

        }

        Writing(s);
    }

    private void Writing(String[] metin) {
        try {
            File dosya = new File("HighScoreTable.txt");
            FileWriter yazici = new FileWriter(dosya, false);
            BufferedWriter yaz = new BufferedWriter(yazici);
            int i = 0;
            while (i < 10 && metin[i] != null) {
                yaz.write(metin[i]);
                yaz.newLine();
                i++;
            }
            yaz.close();
            System.out.println("File Updated Successfully");

            ReadFile();
        } catch (Exception hata) {
            hata.printStackTrace();
        }
    }


    public String[] inputLine = new String[10];

    public boolean ReadFile() throws IOException//score.txt den al�nan veriler  okutulur
    {
        ////
        int i = 0;
        if (!Files.exists(Paths.get("HighScoreTable.txt"))) {
            System.out.println("Score table is empty.");
            return false;
        } else {
            FileReader fileReader = new FileReader("HighScoreTable.txt");
            String line;
            BufferedReader bRead = new BufferedReader(fileReader);
            while ((line = bRead.readLine()) != null) {
                inputLine[i] = line;             // inputline contain input's every line
                i++;
            }
            bRead.close();
            int j = 0;
            while (j < inputLine.length && inputLine[j] != null) {
                String[] parts = inputLine[j].split(";", -1);
                InsertPosition(parts[0], Integer.parseInt(parts[1]));//burada b�y�kten k����e s�ralanabilmesi i�in method cagr�l�r
                j++;
            }
            return true;
        }

    }

    public int size() {
        int count = 0;
        if (head == null) {
        } else {
            DoubleLinkedListNode temp = head;
            while (temp != null) {
                count++;
                temp = temp.getNext();
            }
        }
        return count;
    }


}