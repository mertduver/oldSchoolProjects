import java.awt.Color;
import java.io.IOException;
import java.util.Scanner;

import enigma.console.TextAttributes;
import enigma.core.Enigma;

public class MenuDesign {
    void Menu() throws InterruptedException, IOException {
        Enigma.getConsole("Game", 100, 35, 15, 0);

        int option;
        do {
            Scanner scn = new Scanner(System.in);
            printMenu();
            while (!scn.hasNextInt()) {
                printMenu();
                scn.nextLine();
            }
            option = scn.nextInt();


            if (option == 1) {
                clearScreen();
                HelixSnakeMethods manage = new HelixSnakeMethods();
                Score sc = new Score();
                sc.input();
                Thread.sleep(1000);
                clearScreen();
            } else if (option == 2) {
                DoubleLinkedList m = new DoubleLinkedList();
                clearScreen();
                if (m.ReadFile()) {
                    m.DisplayOnScreeen();
                }
                for (int i = 5; i > 0; i--) {
                    Enigma.getConsole().getTextWindow().setCursorPosition(45, 15);
                    System.out.println("Returning menu in " + i);
                    Thread.sleep(1000);
                }

            }

        } while (option != 3);
        System.exit(1);
    }

    private void printMenu() {
        clearScreen();
        Enigma.getConsole().setTextAttributes(new TextAttributes(Color.green));
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 3);
        System.out.println(" _   _  ____  __    ____  _  _    ___  _  _    __    _  _  ____   ");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 4);
        System.out.println("( )_( )( ___)(  )  (_  _)( \\/ )  / __)( \\( )  /__\\  ( )/ )( ___) ");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 5);
        System.out.println(" ) _ (  )__)  )(__  _)(_  )  (   \\__ \\ )  (  /(__)\\  )  (  )__)  ");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 6);
        System.out.println("(_) (_)(____)(____)(____)(_/\\_)  (___/(_)\\_)(__)(__)(_)\\_)(____) ");
        Enigma.getConsole().setTextAttributes(new TextAttributes(Color.blue));
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 16);
        System.out.println(" _.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 17);
        System.out.println(",'_.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._`.");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 18);
        System.out.println("( (                                                         ) )");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 19);
        System.out.println(" ) )                                                       ( (");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 20);
        System.out.println("( (                                                         ) )");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 21);
        System.out.println(" ) )                                                       ( (");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 22);
        System.out.println("( (                                                         ) )");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 23);
        System.out.println(" ) )                                                       ( (");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 24);
        System.out.println("( (                                                         ) )");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 25);
        System.out.println("( (_.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._) )");
        Enigma.getConsole().getTextWindow().setCursorPosition(10, 26);
        System.out.println("`._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._.-._,'");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 19);
        System.out.println("1)PLAY");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 20);
        System.out.println("2)SCOREBOARD");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 21);
        System.out.println("3)EXIT");
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 22);
        System.out.println();
        Enigma.getConsole().getTextWindow().setCursorPosition(15, 23);
        System.out.println("Choice: ");
        Enigma.getConsole().setTextAttributes(new TextAttributes(Color.white));
        Enigma.getConsole().getTextWindow().setCursorPosition(23, 23);

    }

    void clearScreen() {
        Enigma.getConsole().getTextWindow().setCursorPosition(0, 0);
        for (int i = 0; i < 33; i++) {
            for (int j = 0; j < 99; j++) {
                System.out.print(" ");
            }
            System.out.println();
        }
        Enigma.getConsole().getTextWindow().setCursorPosition(0, 0);
    }
}

