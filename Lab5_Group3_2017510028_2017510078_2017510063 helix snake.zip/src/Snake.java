import java.io.IOException;
import java.util.Random;

import enigma.core.Enigma;

public class Snake {
    private int snakeSpeedThreadSleep = 500;//this will be used for thread.sleep method so if you want to speed up snake,"
    //then you should decrease this value.
    private int x, y;
    private int direction = 0;
    private int lastx = 0;
    private int lasty = 0;
    private int counter = 2;
    Random rnd = new Random();
    private SingleLinkedList snake = new SingleLinkedList();
    MultiLinkedList CodonList;

    public int getSnakeSpeedThreadSleep() {
        return snakeSpeedThreadSleep;
    }

    public Snake() throws IOException {
        CodonList = new MultiLinkedList();
        CodonList.ReadFile();
        x = 10;
        y = 25;
        direction = 1;
        lastx = x;
        lasty = y;
    }

    public int codonScore() {
        String codon;
        int score = 0;
        if (snake.size() % 3 == 0) {
            snake.reverse();
            codon = snake.findCodon();
            score = CodonList.search(codon);
            Enigma.getConsole().getTextWindow().setCursorPosition(62, counter);
            System.out.println(codon + " " + score);
            counter++;
            snake.reverse();
        }
        return score;
    }


    public int codonScoreFirst() {

        String codon;
        int score = 0;
        if (snake.size() % 3 == 0) {
            codon = snake.findCodon();
            score = CodonList.search(codon);
        }
        return score;
    }

    public void addFirst(char[] letters) {
        for (int i = 0; i < 3; i++) {
            addToSnake(letters[rnd.nextInt(4)], lastx, lasty);
            lasty--;
        }
        codonScore();
    }


    public SingleLinkedList getSnake() {
        return snake;
    }


    public void setLastx(int lastx) {
        this.lastx = lastx;
    }


    public void setLasty(int lasty) {
        this.lasty = lasty;
    }

    public void addToSnake(char dataToAdd, int lastx, int lasty) {
        snake.addToEnd(dataToAdd, lastx, lasty);
    }

    public void addToSnakeFront(char dataToAdd, int lastx, int lasty) {
        snake.addFront(dataToAdd, lastx, lasty, direction);
    }


    public void move() {
        if (direction == 1) {
            y++;
        } else if (direction == 2) {
            x--;
        } else if (direction == 3) {
            y--;
        } else if (direction == 0) {
            x++;
        }
    }

    public int getY() {
        return y;
    }


    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public int getX() {
        return x;
    }

}
