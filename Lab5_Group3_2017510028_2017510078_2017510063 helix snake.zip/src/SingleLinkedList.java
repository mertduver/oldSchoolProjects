import enigma.core.Enigma;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;


//i have deleted or haven't wrote unused methods of single linked list because of efficiency.
public class SingleLinkedList {
    public KeyListener klis;
    public int rkey;    // key   (for press/release)
    public enigma.console.Console cn = Enigma.getConsole("Game", 250, 60, 35, 0);

    private SingleLinkedListNode head;

    public SingleLinkedList() {
        head = null;
    }

    public void addFront(Object data, int x, int y, int direction) {

        SingleLinkedListNode newSingleLinkedListNode = new SingleLinkedListNode(data, x, y);
        newSingleLinkedListNode.setLink(head);
        head = newSingleLinkedListNode;

    }

    public void addToEnd(Object data, int x, int y) {//Sona doğru ekleme
        SingleLinkedListNode newSingleLinkedListNode = new SingleLinkedListNode(data, x, y);
        if (head == null) {
            head = newSingleLinkedListNode;
        } else {
            SingleLinkedListNode temp = head;
            while (temp.getLink() != null) {
                temp = temp.getLink();
            }
            temp.setLink(newSingleLinkedListNode);
        }
    }

    public int size() {//boyutunu öðrenme methodu
        SingleLinkedListNode temp = head;
        int counter = 0;
        while (temp != null) {
            counter++;
            temp = temp.getLink();
        }
        return counter;
    }

    //x ve y leri alıp canvasa eklemen lazım

    public void update(char[][] canvas, Snake snake) {
        SingleLinkedListNode temp = head;
        while (temp != null) {
            canvas[temp.getX()][temp.getY()] = (char) temp.getData();
            temp = temp.getLink();
        }
    }


    public boolean isSnake(int x, int y) {
        boolean flag = false;
        SingleLinkedListNode temp = head;
        for (int i = 0; i < size(); i++) {
            if (temp.getX() == x && temp.getY() == y) {
                flag = true;
                break;
            }
            temp = temp.getLink();
        }
        return flag;
    }

    public boolean moveSnakeinSll(char[][] canvas, Snake snake, char[] letters) throws InterruptedException {
        boolean isAteSomething = dinner(canvas, snake, letters);
        SingleLinkedListNode temp = head;

        int x = snake.getX();//başı x y ye ekle
        int y = snake.getY();

        while (temp != null) {
            int xTemp = temp.getX();//şimdikini tut
            int yTemp = temp.getY();
            temp.setX(x);//öncekini şimdikine koy
            temp.setY(y);
            x = xTemp;//az önce tuttuğunu sonrakisine eklemek için x y ye yaz.
            y = yTemp;

            temp = temp.getLink();
        }
        canvas[x][y] = ' ';
        snake.setLastx(x);//yani bunlar ilk 3ü hariç gerekli değil aslında buraya yazmasam da olur çünkü kullanmıyorum
        snake.setLasty(y);//ama belki ilerde lazım olur kullanırım dursun bakalım...
        return isAteSomething;
    }

    public boolean dinner(char[][] canvas, Snake snake, char[] letters) throws InterruptedException {
        if (!isSnake(snake.getX(), snake.getY()) && (!(canvas[snake.getX()][snake.getY()] == ' ' || canvas[snake.getX()][snake.getY()] == '#'))) {//buraya 4 if ile x y ekle ayrı x y ler
            snake.addToSnakeFront(canvas[snake.getX()][snake.getY()], snake.getX(), snake.getY());
            int x = snake.getX();
            int y = snake.getY();
            int direction = snake.getDirection();
            if (direction == 1) {
                y++;
            } else if (direction == 2) {
                x--;
            } else if (direction == 3) {
                y--;
            } else if (direction == 0) {
                x++;
            }
            if (canvas[x][y] == '#') {
                turn(snake);
                Thread.sleep(2 * snake.getSnakeSpeedThreadSleep());
                turn(snake);
            }
            snake.move();
            addingRandomLetter(canvas, letters);
            return true;
        }
        return false;
    }

    public void turn(Snake snake) {
        klis = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            public void keyPressed(KeyEvent e) {
                rkey = e.getKeyCode();
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        };
        if (rkey == KeyEvent.VK_RIGHT)
            snake.setDirection((snake.getDirection() - 1 + 4) % 4);
        else if (rkey == KeyEvent.VK_LEFT)
            snake.setDirection((snake.getDirection() + 1) % 4);
        cn.getTextWindow().addKeyListener(klis);
        rkey = 0;
    }


    public void addingRandomLetter(char[][] canvas, char[] letters) {
        Random rnd = new Random();
        int[] coordinates = selectingEmptyCoordinates(canvas);
        canvas[coordinates[0]][coordinates[1]] = letters[rnd.nextInt(4)];
    }

    private int[] selectingEmptyCoordinates(char[][] canvas) {
        int x, y;
        do {
            Random rnd = new Random();
            x = rnd.nextInt(23) + 1;
            y = rnd.nextInt(58) + 1;
        } while (canvas[x][y] != ' ');
        int[] retValues = new int[2];
        retValues[0] = x;
        retValues[1] = y;
        return retValues;
    }

    public boolean isCrashed() {//kesişiyor başa dönücez
        SingleLinkedListNode temp = head;
        while (temp.getLink().getLink() != null) {
            SingleLinkedListNode temp2 = temp.getLink().getLink();
            while (temp2 != null) {
                if (temp.getX() == temp2.getX() && temp.getY() == temp2.getY()) {
                    return true;
                }
                temp2 = temp2.getLink();
            }
            temp = temp.getLink();
        }
        return false;
    }

    /*  Function to check if list is  empty   */
    public boolean isEmpty() {
        return head == null;
    }

    public void reverse() {
        SingleLinkedListNode prev = null;
        SingleLinkedListNode current = head;
        SingleLinkedListNode next = null;
        while (current != null) {
            next = current.getLink();
            current.setLink(prev);
            ;
            prev = current;
            current = next;
        }
        head = prev;
    }

    public String findCodon() {
        SingleLinkedListNode temp = head;
        int stabil = 3;
        int keepMoving = size() - stabil;
        while (keepMoving > 0) {
            temp = temp.getLink();
            keepMoving--;
        }
        String codon = "";
        int counter = 0;
        while (counter < 3) {
            codon += temp.getData();
            counter++;
            temp = temp.getLink();
        }
        return codon;
    }
}