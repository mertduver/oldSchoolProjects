import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FileOperations fo1 = new FileOperations();
        Graph g1 = fo1.getG();
        HashMap<String, FileOperations.HashMapNode> lineHashim = fo1.getLineHashim();

        Dijkstra dij1 = new Dijkstra(g1, lineHashim);
        ArrayList<SolutionNode> solutions;
        ArrayList<String[]> testStops=fo1.readingTest_stops();
//        for (String[] s:testStops
//             ) {
//
//            String source = s[0];
//            String target = s[1];
//            solutions = dij1.dijkstra_GetMinDistances(source, target, 0, 0);
//            for (int i = 0; i < g1.getVertex(source).getNeighborStops().length; i++) {
//                solutions.addAll(dij1.dijkstra_GetMinDistances(g1.getVertex(source).getNeighborStops()[i][0], target, Integer.parseInt(g1.getVertex(source).getNeighborStops()[i][1]), 0));
//            }
//
//            for (SolutionNode sol : solutions
//            ) {
//                sol.print();
//            }
//
//        }

        while (true) {
            System.out.println("Please enter the stopId's with ';' ");
            Scanner in = new Scanner(System.in);
            String s = in.nextLine();
            String[] line = s.split(";");


            String source = line[0];
            String target = line[1];
            solutions = dij1.dijkstra_GetMinDistances(source, target, 0, 0);
            for (int i = 0; i < g1.getVertex(source).getNeighborStops().length; i++) {
                solutions.addAll(dij1.dijkstra_GetMinDistances(g1.getVertex(source).getNeighborStops()[i][0], target, Integer.parseInt(g1.getVertex(source).getNeighborStops()[i][1]), 0));
            }

            for (SolutionNode sol : solutions
            ) {
                sol.print();
            }
        }
    }
}
