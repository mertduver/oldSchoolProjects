import javafx.util.Pair;

import java.util.ArrayList;
import java.util.LinkedList;

public class Vertex {
    private ArrayList<Edge> edges;
    private String stopId = "";
    private String stopName = "";
    private double coordinateX = 0;
    private double coordinateY = 0;
    private int vehicleTypeId = 0;
    private LinkedList<TripLinkedListNode> trips = new LinkedList<>();
    private String[][] neighborStops;
//    private ArrayList<Pair<String, Integer>> asd;


    public Vertex(String stopId) {
        this.stopId = stopId;
        edges = new ArrayList();
    }


    class TripLinkedListNode {
        public String lineId = "";
        public char direction;
        public int order;
        public String stopId = "";

        public TripLinkedListNode(String lineId, char direction, int order, String stopId) {
            this.lineId = lineId;
            this.direction = direction;
            this.order = order;
            this.stopId = stopId;
        }

        @Override
        public String toString() {
            return "TripLinkedListNode{" +
                    "lineId='" + lineId + '\'' +
                    ", direction=" + direction +
                    ", order=" + order +
                    ", stopId='" + stopId + '\'' +
                    '}';
        }
    }

    public void setEdges(ArrayList<Edge> edges) {
        this.edges = edges;
    }

    public String getStopId() {
        return stopId;
    }

    public void setStopId(String stopId) {
        this.stopId = stopId;
    }

    public String getStopName() {
        return stopName;
    }

    public void setStopName(String stopName) {
        this.stopName = stopName;
    }

    public double getCoordinateX() {
        return coordinateX;
    }

    public void setCoordinateX(double coordinateX) {
        this.coordinateX = coordinateX;
    }

    public double getCoordinateY() {
        return coordinateY;
    }

    public void setCoordinateY(double coordinateY) {
        this.coordinateY = coordinateY;
    }

    public String[][] getNeighborStops() {
        return neighborStops;
    }

    public void setNeighborStops(String[][] neighborStops) {
        this.neighborStops = neighborStops;
    }

    public int getVehicleTypeId() {
        return vehicleTypeId;
    }

    public void setVehicleTypeId(int vehicleTypeId) {
        this.vehicleTypeId = vehicleTypeId;
    }





    public LinkedList<TripLinkedListNode> getTrips() {
        return trips;
    }

    public void setTrips(LinkedList<TripLinkedListNode> trips) {
        this.trips = trips;
    }

    public void addTrip(String lineId, char direction, int order, String stopId) {
        trips.add(new TripLinkedListNode(lineId, direction, order, stopId));
    }

    public void addEdge(Edge e) {
        edges.add(e);
    }

    public ArrayList<Edge> getEdges() {
        return this.edges;
    }

//    private String toStringEdges(){
//        String st="";
//        for (Edge e:edges) {
//            st+=e.getSource()+" "+e.getDestination()+" "+e.getWeight()+" "+ '\'';
//        }
//        return st;
//    }
//    private String toStringNeighbors(){
//        String st="";
//        for (NeighborLinkedListNode n:neighborStops) {
//            st+=n.stopId+" "+n.distance+'\'';
//        }
//        return st;
//    }
//    private String toStringTrips(){
//        String st="";
//        for (TripLinkedListNode t:trips) {
//            st+=t.lineId+" "+t.direction+" "+t.order+" "+t.stopId+'\'';
//        }
//        return st;
//    }

//    @Override
//    public String toString() {
//        return "Vertex{" +
//                "edges=" + toStringEdges() +
//                ", stopId='" + stopId + '\'' +
//                ", stopName='" + stopName + '\'' +
//                ", coordinateX=" + coordinateX +
//                ", coordinateY=" + coordinateY +
//                ", vehicleTypeId=" + vehicleTypeId +
//                ", neighborStops=" + toStringNeighbors() +
//                ", trips=" + toStringTrips() +
//                '}';
//    }


//    @Override
//    public String toString() {
//        return "Vertex{" +
//                "edges=" + edges.get(0).getSource() +
//                ", stopId='" + stopId + '\'' +
//                ", stopName='" + stopName + '\'' +
//                ", coordinateX=" + coordinateX +
//                ", coordinateY=" + coordinateY +
//                ", vehicleTypeId=" + vehicleTypeId +
//                ", neighborStops=" + neighborStops.getFirst().stopId +" "+ neighborStops.getFirst().distance+
//                ", trips=" + trips +
//                '}';
//    }

    @Override
    public String toString() {
        return "Vertex{" +
                "edges=" + edges +
                ", stopId='" + stopId + '\'' +
                ", stopName='" + stopName + '\'' +
                ", coordinateX=" + coordinateX +
                ", coordinateY=" + coordinateY +
                ", vehicleTypeId=" + vehicleTypeId +
                ", trips=" + trips +
                '}';
    }
}
