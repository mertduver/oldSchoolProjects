import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class FileOperations {

    public FileOperations() {
        readingLine();
        readingDistance();
        readingTrip();
        readingStop();
        readingTripToAddMoreEdges();

    }

    HashMap<String, HashMapNode> lineHashim = new HashMap<>();

    Graph g = new Graph();

    public HashMap<String, HashMapNode> getLineHashim() {
        return lineHashim;
    }

    public void setLineHashim(HashMap<String, HashMapNode> lineHashim) {
        this.lineHashim = lineHashim;
    }

    public Graph getG() {
        return g;
    }

    public void setG(Graph g) {
        this.g = g;
    }

    public class HashMapNode {
        public String lineNo;
        public String lineName;
        public char vehicleTypeId;

        public HashMapNode(String lineNo, String lineName, char vehicleTypeId) {
            this.lineNo = lineNo;
            this.lineName = lineName;
            this.vehicleTypeId = vehicleTypeId;
        }

    }

    public ArrayList<String[]> readingTest_stops() {
        ArrayList<String[]> retData = new ArrayList<>();
        try {
            //the file to be opened for reading
            FileInputStream fis = new FileInputStream("test_stops.txt");
            Scanner sc = new Scanner(fis);    //file to be scanned

            sc.nextLine();//skip the first info line

            while (sc.hasNextLine()) {  //returns true if there is another line to read
                //System.out.println(sc.nextLine());      //returns the line that was skipped
                String[] line = sc.nextLine().split(";");
                String[] a = new String[2];
                a[0] = line[0];
                a[1] = line[1];
                retData.add(a);
            }
            sc.close();     //closes the scanner
        } catch (IOException e) {
            e.printStackTrace();
        }
        return retData;
    }


    public void readingTrip() {
        try {
            //the file to be opened for reading
            FileInputStream fis = new FileInputStream("Trip.txt");
            Scanner sc = new Scanner(fis);    //file to be scanned

            sc.nextLine();//skip the first info line

            while (sc.hasNextLine()) {  //returns true if there is another line to read
                //System.out.println(sc.nextLine());      //returns the line that was skipped
                String[] line = sc.nextLine().split(";");
                if (g.getVertex(line[3]) != null) {
                    g.getVertex(line[3]).addTrip(line[0], line[1].charAt(0), Integer.parseInt(line[2]), line[3]);
                }
            }
            sc.close();     //closes the scanner
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readingTripToAddMoreEdges() {
        try {
            //the file to be opened for reading
            FileInputStream fis = new FileInputStream("Trip.txt");
            Scanner sc = new Scanner(fis);    //file to be scanned

            sc.nextLine();//skip the first info line

            String oldStopId = "";
            String oldDirection = "";
            String oldLineId = "";
            while (sc.hasNextLine()) {  //returns true if there is another line to read
                //System.out.println(sc.nextLine());      //returns the line that was skipped
                String[] line = sc.nextLine().split(";");

                if (oldStopId != "" && oldLineId == line[0]) {
                    if (oldDirection == line[1]) {
                        if (line[1] == "0")
                            g.addEdge(oldStopId, line[3], 625);
                        else if (line[1] == "1")
                            g.addEdge(line[3], oldStopId, 625);
                        else
                            System.out.println("there is big errors???");
                    }
                }
                oldStopId = line[3];
            }
            sc.close();     //closes the scanner
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readingStop() {
        try {
            //the file to be opened for reading
            FileInputStream fis = new FileInputStream("Stop.txt");
            Scanner sc = new Scanner(fis);    //file to be scanned

            sc.nextLine();//skip the first info line


            while (sc.hasNextLine()) {  //returns true if there is another line to read
                //System.out.println(sc.nextLine());      //returns the line that was skipped
                String[] line = sc.nextLine().split(";");

                if (g.getVertex(line[0]) == null) {
                    g.addVertex(line[0]);
                }

                g.getVertex(line[0]).setStopName(line[1]);
                g.getVertex(line[0]).setCoordinateX(Double.parseDouble(line[2].replace(',', '.')));
                g.getVertex(line[0]).setCoordinateY(Double.parseDouble(line[3].replace(',', '.')));
                g.getVertex(line[0]).setVehicleTypeId(Integer.parseInt(line[4]));
                String b = line[5];
                b = b.replace('.', ',');
                String[] neighborLine = b.split(",");
                String[][] n2 = new String[neighborLine.length][2];
                for (int i = 0; i < neighborLine.length; i++) {
                    String a[] = neighborLine[i].split(":");
                    if (a.length == 2) {
                        n2[i][0] = a[0];
                        n2[i][1] = a[1];
                    }
                }
                g.getVertex(line[0]).setNeighborStops(n2);
            }

            sc.close();     //closes the scanner
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readingDistance() {
        try {
            //the file to be opened for reading
            FileInputStream fis = new FileInputStream("Distance.txt");
            Scanner sc = new Scanner(fis);    //file to be scanned

            sc.nextLine();//skip the first info line

            while (sc.hasNextLine()) {  //returns true if there is another line to read
                //System.out.println(sc.nextLine());      //returns the line that was skipped
                String[] line = sc.nextLine().split(";");
                g.addEdge(line[0], line[1], Integer.parseInt(line[2]));
            }
            sc.close();     //closes the scanner
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void readingLine() {
        try {
            //the file to be opened for reading
            FileInputStream fis = new FileInputStream("Line.txt");
            Scanner sc = new Scanner(fis);    //file to be scanned

            sc.nextLine();//skip the first info line

            while (sc.hasNextLine()) {  //returns true if there is another line to read
                //System.out.println(sc.nextLine());      //returns the line that was skipped
                String[] line = sc.nextLine().split(";");
                lineHashim.put(line[0], new HashMapNode(line[1], line[2], line[3].charAt(0)));
            }
            sc.close();     //closes the scanner
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

