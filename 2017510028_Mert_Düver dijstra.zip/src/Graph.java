import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Graph {
    private HashMap<String, Vertex> vertices;
    private HashMap<String, Edge> edges;
    private ArrayList<HeapNode> heapNodes;

    Graph() {
        this.vertices = new HashMap<>();
        this.edges = new HashMap<>();
        this.heapNodes= new ArrayList<>();
    }

    public void addEdge(String source, String destination, int weight) {

        if (edges.get(source + "-" + destination) == null) {
            Vertex source_v, destination_v;

//            if (edges.get(source + "-" + destination) == null && edges.get(destination + "-" + source) == null) {
//                Vertex source_v, destination_v;

            if (vertices.get(source) == null) {
                source_v = new Vertex(source);
                vertices.put(source, source_v);
                heapNodes.add(new HeapNode(source,Integer.MAX_VALUE));
            } else source_v = vertices.get(source);

            if (vertices.get(destination) == null) {
                destination_v = new Vertex(destination);
                vertices.put(destination, destination_v);
                heapNodes.add(new HeapNode(destination,Integer.MAX_VALUE));
            } else destination_v = vertices.get(destination);

            Edge edge = new Edge(source_v, destination_v, weight);

            source_v.addEdge(edge);
            destination_v.addEdge(edge);
            edges.put(source + "-" + destination, edge);
        }
    }

    public void print() {

        System.out.println("Source\tDestination\tWeight");
        for (Edge e : edges.values()) {
            System.out.println("" + e.getSource().getStopId() + "\t" + e.getDestination().getStopId() + "\t\t" + e.getWeight() + " ");
        }
    }

    public HashMap<String, Vertex> getVertices() {
        return vertices;
    }

    public Vertex getVertex(String a) {
        return vertices.get(a);
    }

    public ArrayList<HeapNode> getHeapNodes() {
        return heapNodes;
    }

    public void setHeapNodes(ArrayList<HeapNode> heapNodes) {
        this.heapNodes = heapNodes;
    }

    public void setVertices(HashMap<String, Vertex> vertices) {
        this.vertices = vertices;
    }

    public LinkedList<Edge> getEdgesFromVertex(String stopId){
        LinkedList<Edge> retData= new LinkedList<>();
        retData.addAll(vertices.get(stopId).getEdges());
        return retData;
    }

    public void addVertex(String stopId) {
        if (vertices.get(stopId) == null) {
            vertices.put(stopId, new Vertex(stopId));
            heapNodes.add(new HeapNode(stopId,Integer.MAX_VALUE));
        }
    }

    public void setVertex(Vertex a) {
        this.vertices.put(a.getStopId(), a);
    }

    public HashMap<String, Edge> getEdges() {
        return edges;
    }

    public void setEdges(HashMap<String, Edge> edges) {
        this.edges = edges;
    }

    public Iterable<Vertex> vertices() {
        return vertices.values();
    }

    public Iterable<Edge> edges() {
        return edges.values();
    }

    public int size() {
        return vertices.size();
    }
}
