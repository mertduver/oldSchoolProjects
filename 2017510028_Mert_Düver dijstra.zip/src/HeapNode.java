public class HeapNode {
    int vertex;
    int distance;
    String stopId;

    public HeapNode(String stopId, int distance) {
        this.stopId = stopId;
        this.distance = distance;
    }

    public HeapNode() {
    }
}
