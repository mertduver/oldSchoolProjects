import java.util.HashMap;

public class SolutionNode {
    public String lineId;
    public String originStopId;
    public String destinationStopId;
    public int stopCount;
    public int walkbefore =0;
    public int walkafter = 0;
    public int walkmiddle =0;
    public HashMap<String, FileOperations.HashMapNode> lineHashim;
    public int distance;

    public SolutionNode(String lineId, String originStopId, String destinationStopId, HashMap<String, FileOperations.HashMapNode> lineHashim) {
        this.lineId = lineId;
        this.originStopId = originStopId;
        this.destinationStopId = destinationStopId;
        this.lineHashim = lineHashim;
    }

    public void print(){
        System.out.println();
        System.out.println("lineId = " + lineId);
        System.out.println("lineNo = " + lineHashim.get(lineId).lineNo);
        System.out.println("LineName = " + lineHashim.get(lineId).lineName);
        System.out.println("vehicleTypeId = " + lineHashim.get(lineId).vehicleTypeId);
        System.out.println("originStopId = " + originStopId);
        System.out.println("destinationStopId = " + destinationStopId);
        System.out.println("stopCount = " + stopCount);
        System.out.println("distance = " + distance);
        System.out.println("walkbefore = " + walkbefore);
        System.out.println("walkafter = " + walkafter);
        System.out.println("walkmiddle = " + walkmiddle);
        System.out.println();
    }
}