import javafx.util.Pair;

import java.util.*;

public class Dijkstra {
    Graph g;
    HashMap<String, FileOperations.HashMapNode> lineHashim;
    int vertices;
    ArrayList<SolutionNode> solutions= new ArrayList<>();
    public Dijkstra(Graph g, HashMap<String, FileOperations.HashMapNode> lineHashim) {
        this.g = g;
        this.lineHashim = lineHashim;
        this.vertices = g.size();

//        while (true) {
//            Scanner in = new Scanner(System.in);
//            String s = in.nextLine();
//            String[] line = s.split(";");
//
//        }
    }

    public ArrayList<SolutionNode> dijkstra_GetMinDistances(String sourceVertex1, String target,int before,int after) {
        List<String> lines = new ArrayList<>();
        solutions= new ArrayList<>();
        for (Vertex.TripLinkedListNode s : g.getVertex(sourceVertex1).getTrips()
        ) {
            for (Vertex.TripLinkedListNode t : g.getVertex(target).getTrips()
            ) {
                if (s.lineId.equals(t.lineId)&&s.direction==t.direction) {
                    lines.add(s.lineId);
                }
            }
        }
        for (int a = 0; a < lines.size(); a++) {
            int sourceVertex = 0;
            int INFINITY = Integer.MAX_VALUE;
            boolean[] SPT = new boolean[vertices];
            //create heapNode for all the vertices
            HeapNode[] heapNodes = new HeapNode[g.getHeapNodes().size()];

            for (int i = 0; i < g.getHeapNodes().size(); i++) {
                heapNodes[i] = g.getHeapNodes().get(i);
            }


            for (int i = 0; i < vertices; i++) {
                heapNodes[i].vertex = i;
                heapNodes[i].distance = INFINITY;
                if (heapNodes[i].stopId.equals(sourceVertex1)) {
                    heapNodes[i].distance = 0;
                    sourceVertex = i;
                }
            }

            //add all the vertices to the MinHeap
            MinHeap minHeap = new MinHeap(vertices);
            for (int i = 0; i < vertices; i++) {
                for (Vertex.TripLinkedListNode t : g.getVertex(heapNodes[i].stopId).getTrips()
                ) {
                    if (t.lineId.equals(lines.get(a))) {
                        minHeap.insert(heapNodes[i]);
                        break;
                    }
                }
            }
            //while minHeap is not empty
            while (!minHeap.isEmpty()) {
                boolean targetFound=false;
                //extract the min
                HeapNode extractedNode = minHeap.extractMin();

                //extracted vertex
                int extractedVertex = extractedNode.vertex;
                SPT[extractedVertex] = true;

                //iterate through all the adjacent vertices
                LinkedList<Edge> list = g.getEdgesFromVertex(heapNodes[extractedVertex].stopId);
                for (int i = 0; i < list.size(); i++) {
                    Edge edge = list.get(i);
                    int destination = -1;//edge's destination id
                    for (int j = 0; j < heapNodes.length; j++) {
                        if (heapNodes[j].stopId.equals(edge.getDestination().getStopId())) {
                            destination = j;
                            break;
                        }
                    }
                    //only if  destination vertex is not present in SPT
                    if (SPT[destination] == false) {
                        ///check if distance needs an update or not
                        //means check total weight from source to vertex_V is less than
                        //the current distance value, if yes then update the distance
                        int newKey = heapNodes[extractedVertex].distance + edge.getWeight();
                        int currentKey = heapNodes[destination].distance;
                        if (currentKey > newKey) {
                            decreaseKey(minHeap, newKey, destination);
                            heapNodes[destination].distance = newKey;
                            if (heapNodes[destination].stopId.equals(target)){
                                SolutionNode s = new SolutionNode(lines.get(a),sourceVertex1,target,lineHashim);
                                s.distance=newKey;
                                int t1=0,s1=0;
                                for (Vertex.TripLinkedListNode t:g.getVertex(target).getTrips()
                                     ) {
                                    if (t.lineId.equals(lines.get(a))){
                                        t1=t.order;
                                        break;
                                    }
                                }
                                for (Vertex.TripLinkedListNode ss:g.getVertex(sourceVertex1).getTrips()
                                     ) {
                                    if (ss.lineId.equals(lines.get(a))){
                                        s1=ss.order;
                                    }
                                }
                                s.walkbefore=before;
                                s.walkafter=after;
                                s.stopCount=t1-s1;
                                solutions.add(s);
                                targetFound=true;
                                break;
                            }
                        }
                    }
                }
                if (targetFound)
                    break;
            }
            //printDijkstra(heapNodes, sourceVertex);
            //print SPT
        }
        return solutions;
    }

    public void decreaseKey(MinHeap minHeap, int newKey, int vertex) {

        //get the index which distance's needs a decrease;
        int index = minHeap.indexes[vertex];

        //get the node and update its value
        HeapNode node = minHeap.mH[index];
        node.distance = newKey;
        minHeap.bubbleUp(index);
    }

    public void printDijkstra(HeapNode[] resultSet, int sourceVertex) {
        System.out.println("Dijkstra Algorithm: (Adjacency List + Min Heap)");
        for (int i = 0; i < vertices; i++) {
            System.out.println("Source Vertex: " + resultSet[sourceVertex].stopId + " to vertex " + resultSet[i].stopId +
                    " distance: " + resultSet[i].distance);
        }
    }
}

class MinHeap {
    int capacity;
    int currentSize;
    HeapNode[] mH;
    int[] indexes; //will be used to decrease the distance


    public MinHeap(int capacity) {
        this.capacity = capacity;
        mH = new HeapNode[capacity + 1];
        indexes = new int[capacity];
        mH[0] = new HeapNode();
        mH[0].distance = Integer.MIN_VALUE;
        mH[0].vertex = -1;
        currentSize = 0;
    }

    public void display() {
        for (int i = 0; i <= currentSize; i++) {
            System.out.println(" " + mH[i].vertex + "   distance   " + mH[i].distance);
        }
        System.out.println("________________________");
    }

    public void insert(HeapNode x) {
        currentSize++;
        int idx = currentSize;
        mH[idx] = x;
        indexes[x.vertex] = idx;
        bubbleUp(idx);
    }

    public void bubbleUp(int pos) {
        int parentIdx = pos / 2;
        int currentIdx = pos;
        while (currentIdx > 0 && mH[parentIdx].distance > mH[currentIdx].distance) {
            HeapNode currentNode = mH[currentIdx];
            HeapNode parentNode = mH[parentIdx];

            //swap the positions
            indexes[currentNode.vertex] = parentIdx;
            indexes[parentNode.vertex] = currentIdx;
            swap(currentIdx, parentIdx);
            currentIdx = parentIdx;
            parentIdx = parentIdx / 2;
        }
    }

    public HeapNode extractMin() {
        HeapNode min = mH[1];
        HeapNode lastNode = mH[currentSize];
//            update the indexes[] and move the last node to the top
        indexes[lastNode.vertex] = 1;
        mH[1] = lastNode;
        mH[currentSize] = null;
        sinkDown(1);
        currentSize--;
        return min;
    }

    public void sinkDown(int k) {
        int smallest = k;
        int leftChildIdx = 2 * k;
        int rightChildIdx = 2 * k + 1;
        if (leftChildIdx < heapSize() && mH[smallest].distance > mH[leftChildIdx].distance) {
            smallest = leftChildIdx;
        }
        if (rightChildIdx < heapSize() && mH[smallest].distance > mH[rightChildIdx].distance) {
            smallest = rightChildIdx;
        }
        if (smallest != k) {

            HeapNode smallestNode = mH[smallest];
            HeapNode kNode = mH[k];

            //swap the positions
            indexes[smallestNode.vertex] = k;
            indexes[kNode.vertex] = smallest;
            swap(k, smallest);
            sinkDown(smallest);
        }
    }

    public void swap(int a, int b) {
        HeapNode temp = mH[a];
        mH[a] = mH[b];
        mH[b] = temp;
    }

    public boolean isEmpty() {
        return currentSize == 0;
    }

    public int heapSize() {
        return currentSize;
    }
}


