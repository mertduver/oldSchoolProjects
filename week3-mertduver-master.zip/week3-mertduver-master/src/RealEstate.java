import java.util.ArrayList;
//Mert Düver 2017510028
public class RealEstate {
    private String agentName;
    private Address agentAddress;
    private ArrayList<House> houseList;

    public void addHouse(House houseToAdd) {
        houseList.add(houseToAdd);
    }

    public void displayAllHouses() {
        System.out.println("listing all houses");
        searchByPrice(Integer.MIN_VALUE, Integer.MAX_VALUE);
        System.out.println("end of listing all houses");
    }

    public int getNumHouses() {
        return houseList.size();
    }

    public void searchByPrice(int minPrice, int maxPrice) {
        for (House x : houseList
        ) {
            if (minPrice < x.getPrice() && x.getPrice() < maxPrice) {
                System.out.println(x.toString());
            }
        }
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public Address getAgentAddress() {
        return agentAddress;
    }

    public void setAgentAddress(Address agentAddress) {
        this.agentAddress = agentAddress;
    }

    public ArrayList<House> getHouseList() {
        return houseList;
    }

    public void setHouseList(ArrayList<House> houseList) {
        this.houseList = houseList;
    }

    public RealEstate(String agentName, Address agentAddress, ArrayList<House> houseList) {
        this.agentName = agentName;
        this.agentAddress = agentAddress;
        this.houseList = houseList;
    }

}
