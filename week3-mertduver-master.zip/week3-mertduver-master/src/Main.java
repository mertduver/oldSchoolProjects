import java.util.ArrayList;
import java.util.Scanner;
//Mert Düver 2017510028
public class Main {

    public static void main(String[] args) {

        System.out.println("Q2");
        Point p1 = new Point(2, 1);
        Point p2 = new Point(6, 4);
        double distance = Math.sqrt(Math.pow((p2.getX() - p1.getX()), 2) + Math.pow((p2.getY() - p1.getY()), 2));
        System.out.println(distance);

        System.out.println();

        System.out.println("Q4");
        Clock c1 = new Clock("14:50");
        System.out.println(c1.convert());
        Clock c2 = new Clock("01:40");
        System.out.println(c2.convert());

        System.out.println();

        System.out.println("Q3");
        RealEstate r1 = new RealEstate("mert", new Address("atatürk mah.", "buca", "izmir"), new ArrayList<House>());
        int selection;
        do {
            System.out.println("Menu");
            System.out.println("1- Add a house");
            System.out.println("2- Display all houses");
            System.out.println("3- Search by price");
            System.out.println("4- exit");
            Scanner sc = new Scanner(System.in);
            selection = sc.nextInt();
            if (selection == 1) {
                System.out.print("kind: ");
                String kind = sc.next();
                System.out.println();
                System.out.print("number of rooms: ");
                int numberOfRooms = sc.nextInt();
                System.out.println();
                System.out.print("Address Street name: ");
                String streetName = sc.next();
                System.out.println();
                System.out.print("Address Town: ");
                String town = sc.next();
                System.out.println();
                System.out.print("Address City: ");
                String city = sc.next();
                System.out.println();
                System.out.print("area: ");
                int area = sc.nextInt();
                System.out.println();
                System.out.print("price: ");
                int price = sc.nextInt();
                System.out.println();
                r1.addHouse(new House(kind, numberOfRooms, new Address(streetName, town, city), area, price));
            } else if (selection == 2) {
                r1.displayAllHouses();
                System.out.println();
            } else if (selection == 3) {
                System.out.print("Enter min price: ");
                int min = sc.nextInt();
                System.out.println();
                System.out.print("Enter max price: ");
                int max = sc.nextInt();
                System.out.println();
                r1.searchByPrice(min, max);
                System.out.println();
            }
        } while (selection != 4);


    }
}
