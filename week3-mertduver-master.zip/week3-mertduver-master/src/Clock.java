public class Clock {
    private int hour,minute;
    //Mert Düver 2017510028
    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public Clock(String totalHour) {
        String [] splitted=totalHour.split(":");
        this.hour=Integer.parseInt(splitted[0]);
        this.minute=Integer.parseInt(splitted[1]);
    }
    public String convert(){
        String addPart="";
        if (hour<12)
            addPart=" a.m.";
        else{
            addPart=" p.m.";
            hour=hour-12;
        }
        return hour+":"+minute+addPart;
    }
}
