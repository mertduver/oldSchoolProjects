# actually i would want to create methods for reading files and some other jobs
# because currently there are so many duplicated code lines in my python file
# but i just learned arrays and dicts and even python syntax
# so couldn't make an object oriented python code sorry for that

import json
import sys
import xml.etree.ElementTree as elemT
from lxml import etree


# a method for pretty print xml file
# i have taken this method from stackoverflow and edited some parts
def prettify(elem, level=0, more_sibs=False):
    i = "\n"
    if level:
        i += (level - 1) * '    '
    num_kids = len(elem)
    if num_kids:
        if not elem.text or not elem.text.strip():
            elem.text = i + "    "
            if level:
                elem.text += '    '
        count = 0
        for kid in elem:
            prettify(kid, level + 1, count < num_kids - 1)
            count += 1
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
            if more_sibs:
                elem.tail += '    '
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i
            if more_sibs:
                elem.tail += '    '


# csv to xml
if sys.argv[3] == "1":
    # Using readlines()
    file1 = open(sys.argv[1], 'r')
    Lines = file1.readlines()
    Lines.pop(0)
    file1.close()

    second = ""
    name = ""
    spec = "0"

    xml_doc = elemT.Element('departments')

    uniName = ""
    previousUniName = ""

    for line in Lines:
        previousUniName = uniName
        # Strips the newline character
        line = line.strip()
        splitted = line.split(";")
        uniName = splitted[1]
        # if uni name has changed ?? then new uni name should be assigned
        if previousUniName != uniName:
            university = elemT.SubElement(xml_doc, 'university', name=splitted[1], uType=splitted[0])

        item = elemT.SubElement(university, "item", id=splitted[3], faculty=splitted[2])
        second = splitted[6]
        if second == "":
            second = "No"
        spec = splitted[11]
        if spec == "":
            spec = "0"
        elemT.SubElement(item, "name", lang=splitted[5], second=second).text = splitted[4]
        elemT.SubElement(item, "period").text = splitted[8]
        elemT.SubElement(item, "quota", spec=spec).text = splitted[10]
        elemT.SubElement(item, "field").text = splitted[9]
        elemT.SubElement(item, "last_min_score", order=splitted[12]).text = splitted[13]
        elemT.SubElement(item, "grant").text = splitted[7]

    # pretty print for xml document
    prettify(xml_doc)
    tree = elemT.ElementTree(xml_doc)
    tree.write(sys.argv[2], encoding='UTF-8', xml_declaration=True)

# xml to csv
elif sys.argv[3] == "2":
    tree = elemT.parse(sys.argv[1])
    root = tree.getroot()
    file = open(sys.argv[2], "w")
    file.write(
        "ÜNİVERSİTE_TÜRÜ;ÜNİVERSİTE;FAKÜLTE;PROGRAM_KODU;PROGRAM;DİL;ÖĞRENİM_TÜRÜ;BURS;ÖĞRENİM_SÜRESİ;PUAN_TÜRÜ;KONTENJAN;OKUL_BİRİNCİSİ_KONTENJANI;GEÇEN_YIL_MİN_SIRALAMA;GEÇEN_YIL_MİN_PUAN\n")

    # initialize variables
    type = ""
    uni = ""
    faculty = ""
    id = ""
    program = ""
    language = ""
    dayOrNight = ""
    grant = ""
    period = ""
    field = ""
    quota = ""
    specQuota = ""
    minOrder = ""
    minPoints = ""

    for university in root:
        type = university.get("uType")  # i suppose attrib doesn't change anything if i am using the get method ??
        uni = university.attrib.get("name")
        for item in university:
            faculty = item.attrib.get("faculty")
            id = item.attrib.get("id")
            program = item.find("name").text
            language = item.find("name").get("lang")
            dayOrNight = item.find("name").attrib.get("second")
            grant = item.find("grant").text
            if grant is None:
                grant = ""
            period = item.find("period").text
            field = item.find("field").text
            quota = item.find("quota").text
            specQuota = item.find("quota").get("spec")
            minOrder = item.find("last_min_score").get("order")
            minPoints = item.find("last_min_score").text
            if minPoints is None:
                minPoints = ""

            file.write(
                type + ";" + uni + ";" + faculty + ";" + id + ";" + program + ";" + language + ";" + dayOrNight + ";" + grant + ";" + period + ";" + field + ";" + quota + ";" + specQuota + ";" + minOrder + ";" + minPoints + "\n")

    file.close()

# xml to json
elif sys.argv[3] == "3":
    tree = elemT.parse(sys.argv[1])
    root = tree.getroot()

    unis = []

    for university in root:
        departments = []
        universityObject = {"university name": university.attrib.get("name"), "uType": university.get("uType")}
        # i suppose attrib doesn't change anything if i am using the get method ??
        for item in university:
            items = []
            itemObject = {}
            faculty = item.attrib.get("faculty")
            id = item.attrib.get("id")
            program = item.find("name").text
            language = item.find("name").get("lang")
            dayOrNight = item.find("name").attrib.get("second")
            grant = item.find("grant").text
            period = item.find("period").text
            field = item.find("field").text
            quota = item.find("quota").text
            specQuota = item.find("quota").get("spec")
            minOrder = item.find("last_min_score").get("order")
            minPoints = item.find("last_min_score").text

            departmentObject = {"id": id,
                                "name": program,
                                "lang": language,
                                "second": dayOrNight,
                                "period": int(period),
                                "spec": int(specQuota),
                                "quota": int(quota),
                                "field": field,
                                "last_min_score": minPoints,
                                "last_min_order": minOrder,
                                "grant": grant}
            departments.append(departmentObject)

        itemObject = {"faculty": "Mühendislik Fakültesi",
                      "department": departments}
        items.append(itemObject)
        universityObject["items"] = items
        unis.append(universityObject)

    with open(sys.argv[2], 'w', encoding="UTF-8") as json_file:
        json.dump(unis, json_file, indent=4, ensure_ascii=False)

# json to xml
elif sys.argv[3] == "4":
    # opening the json file for read purpose
    with open(sys.argv[1]) as f:
        data = json.load(f)
        # close the file
        f.close()
    xml_doc = elemT.Element('departments')
    # iterating json elements
    for universityInLoop in data:
        university = elemT.SubElement(xml_doc, 'university', name=universityInLoop["university name"],
                                      uType=universityInLoop["uType"])
        for itemInLoop in universityInLoop["items"]:
            for departmentInLoop in itemInLoop["department"]:
                item = elemT.SubElement(university, "item", id=departmentInLoop["id"], faculty=itemInLoop["faculty"])
                elemT.SubElement(item, "name", lang=departmentInLoop["lang"], second=departmentInLoop["second"]).text = \
                    departmentInLoop["name"]
                elemT.SubElement(item, "period").text = str(departmentInLoop["period"])
                elemT.SubElement(item, "quota", spec=str(departmentInLoop["spec"])).text = str(
                    departmentInLoop["quota"])
                elemT.SubElement(item, "field").text = departmentInLoop["field"]
                elemT.SubElement(item, "last_min_score", order=departmentInLoop["last_min_order"]).text = \
                    departmentInLoop["last_min_score"]
                elemT.SubElement(item, "grant").text = departmentInLoop["grant"]
    prettify(xml_doc)
    tree = elemT.ElementTree(xml_doc)
    tree.write(sys.argv[2], encoding='UTF-8', xml_declaration=True)

# csv to json
elif sys.argv[3] == "5":
    # Using readlines()
    file1 = open(sys.argv[1], 'r')
    Lines = file1.readlines()
    Lines.pop(0)
    file1.close()

    second = ""
    name = ""
    spec = "0"

    uniName = ""
    facultyName = ""
    previousUniName = ""
    unis = []
    departments = []
    universityObject = {}
    i = 0
    for line in Lines:
        previousUniName = uniName
        # Strips the newline character
        line = line.strip()
        splitted = line.split(";")
        uniName = splitted[1]
        previousFacultyName = facultyName
        facultyName = splitted[2]
        # if uni name has changed ?? then new uni name should be assigned
        if previousUniName != uniName:
            if i != 0:
                items = []
                item = {"faculty": previousFacultyName, "department": departments}
                items.append(item)
                departments = []
                universityObject["items"] = items
                unis.append(universityObject)

            # new uni starts here
            i = 1
            universityObject = {"university name": splitted[1], "uType": splitted[0]}

        # reassign variables with problem
        second = splitted[6]
        if second == "":
            second = "No"
        spec = splitted[11]
        if spec == "":
            spec = "0"
        grant = splitted[7]
        if grant == "":
            grant = None

        departmentObject = {"id": splitted[3],
                            "name": splitted[4],
                            "lang": splitted[5],
                            "second": second,
                            "period": int(splitted[8]),
                            "spec": int(spec),
                            "quota": int(splitted[10]),
                            "field": splitted[9],
                            "last_min_score": splitted[13],
                            "last_min_order": splitted[12],
                            "grant": grant}
        departments.append(departmentObject)

    items = []
    item = {"faculty": splitted[2], "department": departments}
    items.append(item)
    departments = []
    universityObject["items"] = items
    unis.append(universityObject)

    with open(sys.argv[2], 'w', encoding="UTF-8") as json_file:
        json.dump(unis, json_file, indent=4, ensure_ascii=False)

# json to csv
elif sys.argv[3] == "6":
    file = open(sys.argv[2], "w")
    # write the first line
    file.write(
        "ÜNİVERSİTE_TÜRÜ;ÜNİVERSİTE;FAKÜLTE;PROGRAM_KODU;PROGRAM;DİL;ÖĞRENİM_TÜRÜ;BURS;ÖĞRENİM_SÜRESİ;PUAN_TÜRÜ;KONTENJAN;OKUL_BİRİNCİSİ_KONTENJANI;GEÇEN_YIL_MİN_SIRALAMA;GEÇEN_YIL_MİN_PUAN\n")

    # initialize variables
    type = ""
    uni = ""
    faculty = ""
    id = ""
    program = ""
    language = ""
    dayOrNight = ""
    grant = ""
    period = ""
    field = ""
    quota = ""
    specQuota = ""
    minOrder = ""
    minPoints = ""

    with open(sys.argv[1]) as f:
        data = json.load(f)
        # close the file
        f.close()

    # iterating json elements
    for universityInLoop in data:
        uni = universityInLoop["university name"]
        type = universityInLoop["uType"]
        for itemInLoop in universityInLoop["items"]:
            for departmentInLoop in itemInLoop["department"]:
                id = departmentInLoop["id"]
                faculty = itemInLoop["faculty"]
                language = departmentInLoop["lang"]
                dayOrNight = departmentInLoop["second"]
                program = departmentInLoop["name"]
                period = str(departmentInLoop["period"])
                specQuota = str(departmentInLoop["spec"])
                quota = str(departmentInLoop["quota"])
                field = departmentInLoop["field"]
                minOrder = departmentInLoop["last_min_order"]
                minPoints = departmentInLoop["last_min_score"]
                grant = departmentInLoop["grant"]
                if minPoints is None:
                    minPoints = ""
                if grant is None:
                    grant = ""
                # assign all variables and then write them to the file
                file.write(
                    type + ";" + uni + ";" + faculty + ";" + id + ";" + program + ";" + language + ";" + dayOrNight + ";" + grant + ";" + period + ";" + field + ";" + quota + ";" + specQuota + ";" + minOrder + ";" + minPoints + "\n")
    file.close()

# xsd validation
elif sys.argv[3] == "7":

    doc = etree.parse(sys.argv[1])
    root = doc.getroot()
    # print(etree.tostring(root))
    xmlschema_doc = etree.parse(sys.argv[2])
    xmlschema = etree.XMLSchema(xmlschema_doc)
    doc = etree.XML(etree.tostring(root))
    validation_result = xmlschema.validate(doc)
    print(validation_result)
    xmlschema.assert_(doc)
