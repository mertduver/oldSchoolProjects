public class EmployeeCategory {
    private int employeeCategoryId;
    private String name;

    @Override
    public String toString() {
        return "EmployeeCategory{" +
                "employeeCategoryId=" + employeeCategoryId +
                ", name='" + name + '\'' +
                '}';
    }

    public int getEmployeeCategoryId() {
        return employeeCategoryId;
    }

    public void setEmployeeCategoryId(int employeeCategoryId) {
        this.employeeCategoryId = employeeCategoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EmployeeCategory(int employeeCategoryId, String name) {
        this.employeeCategoryId = employeeCategoryId;
        this.name = name;
    }


}
