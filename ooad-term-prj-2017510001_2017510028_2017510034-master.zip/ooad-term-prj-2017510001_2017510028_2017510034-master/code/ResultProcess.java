import java.util.ArrayList;
import java.util.List;

public class ResultProcess<T> {
    public Result<ArrayList<T>> getListResult(ArrayList<T> data) {

        Result<ArrayList<T>> result = new Result<ArrayList<T>>();
        if (data != null) {
            result.setSucceeded(true);
            result.setUserMessage("process succeeded");
            result.setProcessResult(data);
        } else {
            result.setUserMessage("process not succeeded. No data");
            result.setSucceeded(false);
            result.setProcessResult(null);
        }
        return result;
    }

    public Result<T> getT(T data) {
        Result<T> result = new Result<T>();
        if (data != null) {
            result.setSucceeded(true);
            result.setUserMessage("process succeeded");
            result.setProcessResult(data);
        } else {
            result.setUserMessage("process not succeeded. No data");
            result.setSucceeded(false);
            result.setProcessResult(null);
        }
        return result;
    }
}
