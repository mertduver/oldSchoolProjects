import java.text.SimpleDateFormat;
import java.util.Date;

public class Log  {
    private int userId;
    private String date;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    @Override
    public String toString() {
        return "Log{" +
                "userId=" + userId +
                ", date='" + date + '\'' +
                '}';
    }

    public Log(int userId) {
        Date d=new Date();
        this.userId = userId;
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        this.date=formatter.format(d);
    }
}
