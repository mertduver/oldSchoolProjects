public class Customer extends User{
    private int customerId;
    private String email;
    private String address;
    private String phone;
    private int employeeId;
    private int purchaseCount;

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public int getPurchaseCount() {
        return purchaseCount;
    }

    public void setPurchaseCount(int purchaseCount) {
        this.purchaseCount = purchaseCount;
    }

    public Customer(String name, String surname, String gender, int userId, String userName, String password, int customerId, String email, String address, String phone, int employeeId, int purchaseCount) {
        super(name, surname, gender, userId, userName, password);
        this.customerId = customerId;
        this.email = email;
        this.address = address;
        this.phone = phone;
        this.employeeId = employeeId;
        this.purchaseCount = purchaseCount;
    }
}
