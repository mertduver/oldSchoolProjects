public class Result<T> {
    private String userMessage;
    private boolean isSucceeded;

    @Override
    public String toString() {
        return "Result{" +
                "userMessage='" + userMessage + '\'' +
                ", isSucceeded=" + isSucceeded +
                ", processResult=" + processResult +
                '}';
    }

    private T processResult;

    public String getUserMessage() {
        return userMessage;
    }

    public void setUserMessage(String userMessage) {
        this.userMessage = userMessage;
    }

    public boolean isSucceeded() {
        return isSucceeded;
    }

    public void setSucceeded(boolean succeeded) {
        isSucceeded = succeeded;
    }

    public T getProcessResult() {
        return processResult;
    }

    public void setProcessResult(T processResult) {
        this.processResult = processResult;
    }
}
