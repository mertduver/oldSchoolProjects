import java.text.ParseException;

public class Main {

    public static void main(String[] args) throws ParseException {
        // write your code here
        Device device = new Device(2, 1, 300500);
        System.out.println("maindeki"+device.getProductId());
        ProductRepository prorep= new ProductRepository();
        prorep.insert(device);
        Invoice inv = new Invoice(2);
        System.out.println(inv.getTaxFreePrice());
        inv.calculateTaxFreePrice();
        System.out.println(inv.getTaxFreePrice());

    }
}
