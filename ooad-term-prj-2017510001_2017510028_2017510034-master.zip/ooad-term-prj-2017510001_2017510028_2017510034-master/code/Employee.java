public class Employee extends User {
    private int employeeId;
    private double salary;
    private String birthDate;
    private String fireDate;
    private String phone;
    private int employeeCategoryId;
    private int sellCount;

    public Employee(String name, String surname, String gender, int userId, String userName, String password, int employeeId, double salary, String birthDate, String fireDate, String phone, int employeeCategoryId, int sellCount) {
        super(name, surname, gender, userId, userName, password);
        this.employeeId = employeeId;
        this.salary = salary;
        this.birthDate = birthDate;
        this.fireDate = fireDate;
        this.phone = phone;
        this.employeeCategoryId = employeeCategoryId;
        this.sellCount = sellCount;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getFireDate() {
        return fireDate;
    }

    public void setFireDate(String fireDate) {
        this.fireDate = fireDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getEmployeeCategoryId() {
        return employeeCategoryId;
    }

    public void setEmployeeCategoryId(int employeeCategoryId) {
        this.employeeCategoryId = employeeCategoryId;
    }

    public int getSellCount() {
        return sellCount;
    }

    public void setSellCount(int sellCount) {
        this.sellCount = sellCount;
    }
}
