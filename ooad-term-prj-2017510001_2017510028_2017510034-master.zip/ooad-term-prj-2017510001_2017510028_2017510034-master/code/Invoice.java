import java.util.Date;

public class Invoice {
    private int invoiceId;
    private int customerId;
    private int productId;
    private int supplierId;
    private double taxPrice;
    private double VAT;
    private double tip;
    private double taxFreePrice;
    private String address;
    private Date sellDate;

    public Invoice(int productId) {
        this.productId = productId;
    }

    public void calculateTaxPrice() {

    }

    //todo bişiler
    void calculateTaxFreePrice() {
        ProductRepository proRep = new ProductRepository();
        Product data = (Product) proRep.getObjectById(productId).getProcessResult();

        this.taxFreePrice = data.getPrice();
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "invoiceId=" + invoiceId +
                ", customerId=" + customerId +
                ", productId=" + productId +
                ", supplierId=" + supplierId +
                ", taxPrice=" + taxPrice +
                ", VAT=" + VAT +
                ", tip=" + tip +
                ", taxFreePrice=" + taxFreePrice +
                ", address='" + address + '\'' +
                ", sellDate=" + sellDate +
                '}';
    }

    public Invoice(int invoiceId, int customerId, int productId, int supplierId, double tip, String address) {
        this.invoiceId = invoiceId;
        this.customerId = customerId;
        this.productId = productId;
        this.supplierId = supplierId;
        this.tip = tip;
        this.address = address;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public double getTaxPrice() {
        calculateTaxPrice();
        return taxPrice;
    }

    public void setTaxPrice(double taxPrice) {
        this.taxPrice = taxPrice;
    }

    public double getVAT() {
        return VAT;
    }

    public void setVAT(double VAT) {
        this.VAT = VAT;
    }

    public double getTip() {
        return tip;
    }

    public void setTip(double tip) {
        this.tip = tip;
    }

    public double getTaxFreePrice() {
      //  calculateTaxFreePrice();
        return taxFreePrice;
    }

    public void setTaxFreePrice(double taxFreePrice) {
        this.taxFreePrice = taxFreePrice;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getSellDate() {
        return sellDate;
    }

    public void setSellDate(Date sellDate) {
        this.sellDate = sellDate;
    }
}
