import java.util.List;

public interface DataRepository<T,M> {
    public void insert(T item);
    public Result<Integer> update(T item);
    public Result<Integer> delete(M id);
    public Result<List<T>> list();
    public Result<T> getObjectById(int id);

}
