public class Album extends Product {
    private int albumId;
    private String releaseDate;
    private String artistName;
    private int genreId;

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public int getGenreId() {
        return genreId;
    }

    public void setGenreId(int genreId) {
        this.genreId = genreId;
    }

    public Album(int productId, int supplierId, int categoryId, int stock, String name, double price, int albumId,  String releaseDate, String artistName, int genreId) {
        super(productId, supplierId, categoryId, stock, name, price);
        this.albumId = albumId;
        this.releaseDate = releaseDate;
        this.artistName = artistName;
        this.genreId = genreId;
    }
}
