import java.util.ArrayList;

public class ProductRepository implements DataRepository {
    private static ArrayList<Product> productsList= new ArrayList<>();
    ResultProcess<Product> result= new ResultProcess<>();


    //todo insert
    @Override
    public void insert(Object item) {
        productsList.add((Product) item);
    }

    @Override
    public Result<Integer> update(Object item) {
        return null;
    }

    @Override
    public Result<Integer> delete(Object id) {
        return null;
    }

    @Override
    public Result<ArrayList<Product>> list() {
        return result.getListResult(productsList);
    }

    @Override
    public Result getObjectById(int id) {
        Product data=null;
        for (Product x:productsList
        ) {
            if (x.getProductId()==id){
                data=x;
            }
        }
        return result.getT(data);
    }
}
