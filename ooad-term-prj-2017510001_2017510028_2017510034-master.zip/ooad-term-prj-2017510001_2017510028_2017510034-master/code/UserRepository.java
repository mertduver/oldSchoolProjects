import java.util.ArrayList;

public class UserRepository implements DataRepository {
    private static ArrayList<User> userList= new ArrayList<>();
    ResultProcess<User> result= new ResultProcess<>();


    //todo insert
    @Override
    public void insert(Object item) {
        userList.add((User) item);
    }

    @Override
    public Result<Integer> update(Object item) {
        return null;
    }

    @Override
    public Result<Integer> delete(Object id) {
        return null;
    }

    @Override
    public Result<ArrayList<User>> list() {
        return result.getListResult(userList);
    }

    @Override
    public Result getObjectById(int id) {
        User data=null;
        for (User x:userList
        ) {
            if (x.getUserId()==id){
                data=x;
            }
        }
        return result.getT(data);
    }
}
