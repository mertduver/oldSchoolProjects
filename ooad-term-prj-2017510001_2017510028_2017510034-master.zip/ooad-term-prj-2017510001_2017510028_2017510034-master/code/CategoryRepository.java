import java.util.ArrayList;

public class CategoryRepository implements DataRepository{
    private static ArrayList<InstrumentCategory> categoryList= new ArrayList<>();
    ResultProcess<InstrumentCategory> result= new ResultProcess<>();

    @Override
    public void insert(Object item) {
        categoryList.add((InstrumentCategory) item);
    }

    @Override
    public Result<Integer> update(Object item) {
        return null;
    }

    @Override
    public Result<Integer> delete(Object id) {
        return null;
    }

    @Override
    public Result<ArrayList<InstrumentCategory>> list() {
        return result.getListResult(categoryList);
    }

    @Override
    public Result getObjectById(int id) {
        InstrumentCategory data=null;
        for (InstrumentCategory x:categoryList
        ) {
            if (x.getId()==id){
                data=x;
            }
        }
        return result.getT(data);
    }
}
