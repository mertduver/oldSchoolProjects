import java.lang.reflect.Array;
import java.util.ArrayList;

public class Management {
    ArrayList<Log> logList=new ArrayList<Log>();

    public void login(){}
    public long totalIncome(){return 0;}
    public void sell(){}
    public void search(){}
    public double calculateSalary(){return 0;}
    public double calculateTip(){return 0;}
    public void checkLogOperation(){}
    public void checkCustomerDiscount(){}
    public void checkWarranty(){}
    public void changeOperation(){}
}
