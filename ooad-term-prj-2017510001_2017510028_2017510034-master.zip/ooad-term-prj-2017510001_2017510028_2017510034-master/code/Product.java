import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public abstract class Product {
    private int productId;
    private int supplierId;
    private int categoryId;
    private int stock;
    private String name;
    private boolean discounted;
    private double price;
    private Date dateOfPurchase;//date of the item arrives to shop

    public Product(int productId, double price) {
        this.productId = productId;
        this.price = price;
    }

    public boolean isDiscounted() throws ParseException {
        Date now=new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
        Date firstDate = sdf.parse(sdf.format(dateOfPurchase));
        Date secondDate = sdf.parse(sdf.format(now));
        long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
        long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        discounted=diff>=60;
        return diff>=60;
    }

    public Product(int productId, int supplierId, int categoryId, int stock, String name, double price) {
        this.productId = productId;
        this.supplierId = supplierId;
        this.categoryId = categoryId;
        this.stock = stock;
        this.name = name;
        this.discounted = false;
        this.price = price;
        this.dateOfPurchase = new Date();
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDiscounted(boolean discounted) {
        this.discounted = discounted;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Date getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(Date dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", supplierId=" + supplierId +
                ", categoryId=" + categoryId +
                ", stock=" + stock +
                ", name='" + name + '\'' +
                ", discounted=" + discounted +
                ", price=" + price +
                ", dateOfPurchase=" + dateOfPurchase +
                '}';
    }
}
