public class Instruments extends Product {
    private int instrumentsId;
    private String instrumentId;
    private String colour;
    private String brand;
    private String model;
    private int instrumentCategoryId;

    @Override
    public String toString() {
        return "Instruments{" +
                "instrumentsId=" + instrumentsId +
                ", instrumentId='" + instrumentId + '\'' +
                ", colour='" + colour + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", instrumentCategoryId=" + instrumentCategoryId +
                '}';
    }

    public Instruments(int productId, int supplierId, int categoryId, int stock, String name, double price, int instrumentsId, String instrumentId, String colour, String brand, String model, int instrumentCategoryId) {
        super(productId, supplierId, categoryId, stock, name, price);
        this.instrumentsId = instrumentsId;
        this.instrumentId = instrumentId;
        this.colour = colour;
        this.brand = brand;
        this.model = model;
        this.instrumentCategoryId = instrumentCategoryId;
    }

    public int getInstrumentsId() {
        return instrumentsId;
    }

    public void setInstrumentsId(int instrumentsId) {
        this.instrumentsId = instrumentsId;
    }

    public String getInstrumentId() {
        return instrumentId;
    }

    public void setInstrumentId(String instrumentId) {
        this.instrumentId = instrumentId;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getInstrumentCategoryId() {
        return instrumentCategoryId;
    }

    public void setInstrumentCategoryId(int instrumentCategoryId) {
        this.instrumentCategoryId = instrumentCategoryId;
    }
}
