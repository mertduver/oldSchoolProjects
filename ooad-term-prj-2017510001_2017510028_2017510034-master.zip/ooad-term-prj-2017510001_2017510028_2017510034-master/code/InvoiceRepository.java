import java.util.ArrayList;

public class InvoiceRepository implements DataRepository {
    private static ArrayList<Invoice> invoiceList= new ArrayList<>();
    ResultProcess<Invoice> result= new ResultProcess<>();

    @Override
    public void insert(Object item) {
    }

    @Override
    public Result<Integer> update(Object item) {
        return null;
    }

    @Override
    public Result<Integer> delete(Object id) {
        return null;
    }

    @Override
    public Result<ArrayList<Invoice>> list() {
            return result.getListResult(invoiceList);
    }

    @Override
    public Result getObjectById(int id) {
        Invoice data=null;
        for (Invoice x:invoiceList
             ) {
            if (x.getInvoiceId()==id){
                data=x;
            }
        }
        return result.getT(data);
    }
}
