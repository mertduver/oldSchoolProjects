﻿CREATE TABLE university (
"university_id" serial,
"name" varchar(200) NOT NULL,
"address" varchar(500),
"e-mail_address" varchar(200),
"city" varchar(50) NOT NULL,
"university_type" varchar(20) NOT NULL,
"year_of_foundation" int NOT NULL,
CONSTRAINT "pk_university_id" PRIMARY KEY("university_id"),
CONSTRAINT "un_uni_name" UNIQUE("name"))


CREATE TABLE faculty (
"faculty_id" serial,
"name" varchar(200) NOT NULL,
"e-mail_address" varchar(200),
"connected_university" int NOT NULL,
CONSTRAINT "pk_faculty_id" PRIMARY KEY("faculty_id"),
CONSTRAINT "un_faculty_name" UNIQUE("name","connected_university"),
CONSTRAINT "fk_connected_university" FOREIGN KEY("connected_university")
REFERENCES university("university_id") match simple
ON UPDATE CASCADE ON DELETE CASCADE )

insert into faculty("name","connected_university")
values('mükemmellikk fakültesi',2)

select * from faculty

CREATE TABLE department (
"department_id" serial,
"name" varchar(200) NOT NULL,
"e-mail_address" varchar(200),
"min_score" int NOT NULL,
"min_order" varchar(20),
"connected_faculty" int NOT NULL,
"education_period" int NOT NULL,
"quota_for_top_ranked" int,
"quota" int,
"education_type" varchar(50) NOT NULL,
"language" varchar(100),
CONSTRAINT "pk_department_id" PRIMARY KEY("department_id"),
CONSTRAINT "un_dept_name" UNIQUE("name","connected_faculty","education_type"),
CONSTRAINT "fk_connected_faculty" FOREIGN KEY("connected_faculty")
REFERENCES faculty("faculty_id") match simple
ON UPDATE CASCADE ON DELETE CASCADE )

insert into department("name","min_score","connected_faculty","education_period","education_type")
values('Department of Computer Engineering',450,5,5,'iö'),('Makine Mühendisliği',400,5,5,'iö'),('Makine Mühendisliği',420,5,5,'öö')


insert into department("name","min_score","connected_faculty","education_period","education_type")
values('Department of Computer engineering',450,5,5,'iö')


select * from faculty INNER JOIN university ON faculty."connected_university"=university."university_id"

insert into university ("name","city","university_type","year_of_foundation")
values('antep üniversitesi','gaziantep','devlet',1987),('mert üniversitesi','mertistan','çok özel',1505)

Select * from university


insert into university ("name","city","university_type","year_of_foundation")
values('demokrasi üniversitesi','izmir','devlet',2016),
('Dokuz Eylül University','İzmir','devlet',1982),
('Kâtip Çelebi Üniversitesi','İzmir','devlet',2010)

Select * from faculty as f INNER JOIN university as u ON f."connected_university"=u."university_id"

Select * from university where city LIKE 'i%' OR city LIKE 'İ%'

Select * from university where city LIKE 'İ%' and year_of_foundation>1990


insert into faculty("name","connected_university")
values('Engineering',5)


insert into faculty("name","connected_university")
values('Engineering',3)

Select u."name" from university as u INNER JOIN faculty as f ON f."name"= 'Engineering' and f."connected_university"=u."university_id"
INTERSECT
Select u."name" from university as u INNER JOIN faculty as f ON f."name"= 'Medicine' and f."connected_university"=u."university_id"

Select count(DISTINCT faculty."name") from faculty


insert into department("name","min_score","connected_faculty","education_period","education_type")
values('Machine engineering',400,8,5,'iö'),('Machine engineering',420,8,5,'öö')

SELECT * FROM department WHERE name like '%engineering%' and department."education_type"='iö'



insert into department("name","min_score","connected_faculty","education_period","education_type")
values('Electrical engineering',400,8,8,'iö'),('Electrical engineering',420,8,7,'öö')


Select * from department order by department."education_period" desc limit 5

Select * from department order by department."min_score" desc limit 5


insert into university ("name","city","university_type","year_of_foundation")
values('Izmir Technical University','İzmir','devlet',2020)

update faculty
set "connected_university"=7
where faculty_id=5



insert into faculty("name","connected_university")
values('Faculty of Law',1),('Faculty of Law',4),('Faculty of Law',5)


insert into department("name","min_score","connected_faculty","education_period","education_type")
values('Hukuk',187,10,5,'öö'),('Hukuk',210,11,3,'öö'),('Hukuk',187,12,2,'öö'),('Hukuk',188,12,6,'iö')


update department
SET education_period=education_period+1
where department."connected_faculty"=10 OR department."connected_faculty"=11 OR department."connected_faculty"=12



insert into university ("name","city","university_type","year_of_foundation")
values('İzmir University','İzmir','devlet',2012)


insert into faculty("name","connected_university")
values('Art',8)


insert into department("name","min_score","connected_faculty","education_period","education_type")
values('Computer Engineering',387,13,50,'öö'),('Medicine',210,14,3,'öö'),('Paint',187,15,2,'öö'),('Machine Engineering',288,13,1,'iö')

--10
delete from faculty
where connected_university=8
