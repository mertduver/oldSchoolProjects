# university-preference-system-mertduver
university-preference-system-mertduver created by GitHub Classroom

2017510028 

mert düver 

-q6 and q7 don't exist.
