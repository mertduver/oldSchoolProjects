public class Node {
    String pathName;
    int number=0;
    Node link;

    public Node(String  dataToAdd) {
        pathName = dataToAdd;
        link = null;
        number=1;
    }
    public void addNumber(){
        number++;
    }

    public String getPathName() {
        return pathName;
    }

    public void setPathName(String pathName) {
        this.pathName = pathName;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public Node getLink() {
        return link;
    }

    public void setLink(Node link) {
        this.link = link;
    }
}
