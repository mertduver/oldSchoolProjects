import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        // write your code here
        int a = 2147483647;
        int b = 1111111111;


        System.out.println(a);
        System.out.println(b);
        System.out.println();

        //folder operations

      /*  Hashtable h1 = new Hashtable();
        h1.put("a","1");
        h1.put("a","2");
        h1.put("c","3");
        h1.put("d","4");
        h1.put("e","5");
        h1.get("a");
        h1.get("b");
        h1.get("c");
        h1.get("d");
        h1.get("e");
        h1.get("f");
        h1.get("aa");
*/

        FileOperations f=new FileOperations();



/*


        Hashtable h = new Hashtable();
        h.put("a","dfgdfg");
        h.put("a","1");
        h.put("a","2");
        h.put("a","1");

        h.get("a");
        h.put("mertosss");
        h.put("mertosşs");
        h.put("mert", "deneme1.txt");
        h.put("mertik", "deneme2.txt");
        h.put("b", "baba1.txt");
        h.put("mert", "a.txt");
        h.put("mertosss", "b.txt");
        System.out.println(h.getN());
        System.out.println(h.getCapacity());
        h.get("mertosşs");


        h.get("mert");
        h.get("b");
        h.get("mertosss");
        h.get("mertik");
        h.get("mertossss");

*/

    }
}
