
public class SingleLinkedList {
    private Node head;

    public SingleLinkedList() {
        head = null;
    }

    private void addToEnd(String dataToAdd) {
        Node newNode = new Node(dataToAdd);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;

            while (temp.getLink() != null) {
                temp = temp.getLink();
            }

            temp.setLink(newNode);
        }
    }
    public String toStringHorizantally(){
        Node temp=head;
        String retData="";
        if (head==null)
            return " ";
        while (temp.getLink()!=null){
            retData+=(temp.pathName+": "+temp.getNumber()+"  ");
            temp=temp.getLink();
        }
        retData+=(temp.pathName+": "+temp.getNumber()+"  ");
        return retData;
    }

    public void addData(String dataToAdd){
    	Node temp=head;
    	boolean exist=false;
		while (temp != null) {
			if (temp.getPathName() == dataToAdd) {
				temp.addNumber();
				exist=true;
				break;
			}
			temp = temp.getLink();
		}
		if (!exist){
			addToEnd(dataToAdd);
		}
	}

    public void print() {
        if (head==null){
            System.out.println("Not found!");
        }else{
            System.out.println(size()+" documents found");
            Node temp = head;
            while (temp!=null){
                System.out.println(temp.getNumber()+" - "+temp.getPathName());
                temp=temp.getLink();
            }
        }

    }

    public void remove(Object dataToRemove) {
        if (head == null) {
            System.err.println("The Linked List is empty");
        } else {
            while ((int) head.getNumber() == (int) dataToRemove) {
                head = head.getLink();
            }

            Node temp = head;
            Node prev = null;
            while (temp != null) {

                if ((int) temp.getNumber() == (int) dataToRemove) {
                    prev.setLink(temp.getLink());
                    temp = temp.getLink();
                } else {
                    prev = temp;
                    temp = temp.getLink();
                }
            }
        }
    }

    public int size() {
        if (head == null) {
            System.err.println("The Linked List is empty");
            return 0;
        } else {
            int counter = 0;

            Node temp = head;
            while (temp != null) {
                counter++;
                temp = temp.getLink();
            }

            return counter;
        }
    }

    public boolean search(Object dataToSearch) {
        if (head == null) {
            return false;
        } else {
            Node temp = head;

            boolean retVal = false;
            while (temp != null) {
                if (temp.getPathName() == dataToSearch) {
                    retVal = true;
                    break;
                }

                temp = temp.getLink();
            }

            return retVal;
        }
    }

    public int findMax() {
        if (head == null) {
            System.err.println("The Linked List is empty");
            return Integer.MIN_VALUE;
        } else {

            int maxVal = Integer.MIN_VALUE;

            Node temp = head;

            while (temp != null) {
                if ((int) temp.getNumber() > maxVal) {
                    maxVal = (int) temp.getNumber();
                }

                temp = temp.getLink();
            }

            return maxVal;
        }
    }

}












