public class HashEntry {
    private String key;
    private SingleLinkedList value;

    HashEntry(String key) {
        this.key = key;
        this.value = new SingleLinkedList();
    }

    HashEntry(String key, String data) {
        this.key = key;
        this.value = new SingleLinkedList();
         value.addData(data);
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public SingleLinkedList getValue() {//---
        return value;
    }

    public void addValue(String dataToAdd){
        value.addData(dataToAdd);
    }
}
