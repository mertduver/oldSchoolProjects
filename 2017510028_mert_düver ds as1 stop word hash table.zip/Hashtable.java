
public class Hashtable {
    private int capacity = 128;
    private int n = 0; // number of entries
    private long collusionCounter = 0;
    private HashEntry[] table;

    Hashtable() {
        table = new HashEntry[capacity];
        for (int i = 0; i < capacity; i++)
            table[i] = null;
    }

    private int hashFunction(int key) {
        return key % capacity;
    }


    public void get(String key) {//prints directly, not returns.

        int hash = hashFunction(SimpleSummationFunction(key));

        boolean flag = false;
        while (table[hash] != null) {
            if (table[hash].getKey().equals(key)) {
                System.out.println();
                System.out.println("Search: " + key);
                table[hash].getValue().print();
                System.out.println();
                flag = true;
                break;
            }
            hash = hashFunction(hash + 1);
        }
        if (!flag)
            System.out.println("null");
    }

    public void put(String key, String value) {
        n++;
        if (size() >= capacity / 2) {
            resize();
        }
        int hash = hashFunction(SimpleSummationFunction(key));
        while (table[hash] != null && !table[hash].getKey().equals(key)) {
            collusionCounter++;
            hash = hashFunction(hash + 1);
        }
        if (table[hash] == null) {
            table[hash] = new HashEntry(key, value);
        } else {
            table[hash].getValue().addData(value);
        }
    }


    public int getN() {
        return n;
    }


    public int getCapacity() {
        return capacity;
    }


    private int SimpleSummationFunction(String key) {
        char[] letters = key.toCharArray();
        int sum = 0;
        for (int i = 0; i < letters.length; i++) {
            sum += letters[i] - 96;
        }
        return sum;

    }


    private int size() {
        int counter = 0;
        for (int i = 0; i < table.length; i++) {
            if (table[i] != null)
                counter++;
        }
        return counter;
    }

    private void resize() {
        HashEntry[] temp = table;
        capacity = capacity * 2;
        boolean flag;
        do {//loop to find the next prime
            capacity++;
            flag = true;
            for (int i = 2; i < capacity; i++) {
                if (capacity % i == 0) {
                    flag = false;
                    break;
                }
            }
        } while (!flag);
        table = new HashEntry[capacity];
        for (int i = 0; i < temp.length; i++) {
            if (temp[i] != null) {
                table[hashFunction(SimpleSummationFunction(temp[i].getKey()))] = temp[i];
            }
        }
    }

    public void printAllHashTable() {
        System.out.println();
        for (int i = 0; i < table.length; i++) {
            if (table[i] != null) {
                System.out.print(i + " " + table[i].getKey());
                for (int j = 0; j < 34 - table[i].getKey().length(); j++) {
                    System.out.print(" ");
                }
                System.out.println(table[i].getValue().toStringHorizantally());
            } else
                System.out.println(i + " null");
        }
    }
}
