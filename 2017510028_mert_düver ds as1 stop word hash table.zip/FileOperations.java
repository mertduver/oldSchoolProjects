import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FileOperations {
    BufferedReader br = new BufferedReader(new FileReader("stop_words_en.txt"));
    private String[] stops = new String[571];
    private ArrayList<String> paths = new ArrayList<>();
    Hashtable hashlerim = new Hashtable();
    String DELIMITERS = "[-+=" +
            " " +        //space
            "\r\n " +    //carriage return line fit
            "1234567890" + //numbers
            "’\"" +       // apostrophe
            "(){}<>\\[\\]" + // brackets
            ":" +        // colon
            "," +        // comma
            "‒–—―" +     // dashes
            "…" +        // ellipsis
            "!" +        // exclamation mark
            "." +        // full stop/period
            "«»" +       // guillemets
            "-‐" +       // hyphen
            "?" +        // question mark
            "‘’“”" +     // quotation marks
            ";" +        // semicolon
            "/" +        // slash/stroke
            "⁄" +        // solidus
            "␠" +        // space?
            "·" +        // interpunct
            "&" +        // ampersand
            "@" +        // at sign
            "*" +        // asterisk
            "\\" +       // backslash
            "•" +        // bullet
            "^" +        // caret
            "¤¢$€£¥₩₪" + // currency
            "†‡" +       // dagger
            "°" +        // degree
            "¡" +        // inverted exclamation point
            "¿" +        // inverted question mark
            "¬" +        // negation
            "#" +        // number sign (hashtag)
            "№" +        // numero sign ()
            "%‰‱" +      // percent and related signs
            "¶" +        // pilcrow
            "′" +        // prime
            "§" +        // section sign
            "~" +        // tilde/swung dash
            "¨" +        // umlaut/diaeresis
            "_" +        // underscore/understrike
            "|¦" +       // vertical/pipe/broken bar
            "⁂" +        // asterism
            "☞" +        // index/fist
            "∴" +        // therefore sign
            "‽" +        // interrobang
            "※" +          // reference mark
            "]";


    public FileOperations() throws IOException {


        String thisLine;
        int n = 0;
        while ((thisLine = br.readLine()) != null) {
            stops[n] = thisLine;
            n++;
        }

        final File folder = new File("bbc");
        ArrayList<String> filesPathList = listFilesForFolder(folder);

        /*for (String a:filesPathList) {
            System.out.println(a);
        }*/

        //loop for each file
        for (String currentFile : filesPathList) {

            System.out.println("reading.. "+currentFile);


            String text = "";
            text = new String(Files.readAllBytes(Paths.get(currentFile)));
            text = text.toLowerCase();


            String[] temp_splitted = text.split(DELIMITERS);

            List<String> splitted = Arrays.asList(temp_splitted);
            splitted = stopWordChecker(splitted);
            String text2 = "";
            for (String str : splitted) {
                text2 += str;
                text2 += " ";
            }
            String[] temp_splitted2 = text2.split("[ ']");
            List<String> splitted2 = Arrays.asList(temp_splitted2);
            splitted2 = stopWordChecker(splitted2);
            for (String str : splitted2) {
                if (str != null) {
                    hashlerim.put(str, currentFile);
                }
            }
        }
        hashlerim.printAllHashTable();
        hashlerim.get("car");
        hashlerim.get("profits");
        hashlerim.get("fuel");
    }

    private List<String> stopWordChecker(List<String> splitted) {
        for (String str : splitted//stop words check and delete
        ) {
            for (int i = 0; i < stops.length; i++) {
                if (str != null) {
                    if (str.equals(stops[i])) {
                        str = null;
                        break;
                    }
                }
            }
        }
        return splitted;
    }


    //recursive function
    public ArrayList<String> listFilesForFolder(final File folder) {

        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                listFilesForFolder(fileEntry);
            } else {
                paths.add(fileEntry.getPath());
            }
        }
        return paths;
    }




/*
try (
    Stream<Path> paths = Files.walk(Paths.get("/home/you/Desktop"))) {
    paths
        .filter(Files::isRegularFile)
        .forEach(System.out::println);
}
*/
}
